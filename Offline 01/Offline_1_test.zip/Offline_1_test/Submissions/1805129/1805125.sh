#!/bin/bash
# 1805129

echo "Four score and seven years ago,     yo"
echo " our big daddy brought forth on  this continent"
echo "  a new nation, conceived in Liberty   n stuff,"
echo "  I used to rule the world"
