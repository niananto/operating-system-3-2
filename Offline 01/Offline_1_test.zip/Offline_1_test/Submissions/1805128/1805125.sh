#!/bin/bash
# 1805128

echo "Four score and seven years ago,     yo"
echo " our big daddy brought forth on  this continent"
echo "  a new nation, conceived in Liberty   n stuff,"
echo "    Sees would rise when I gave the word"
